const formC = document.querySelector('#form-create')
const formL = document.querySelector('#form-login')
const loginInput = document.querySelector('#login-input')
const createInput = document.querySelector('#create-input')
const noti = document.querySelector('.notification')

formC.addEventListener('submit', async e=>{
    e.preventDefault()
    // metodos
    //CRUD
    // CREATE = POST : colocar elementos
    // READ = GET : obtener elementos
    // UPDATE = PUT/PATCH
    // DELETE  = DELETE
    


    const url = 'http://localhost:3000/usuarios'
    // consultar los usuarios que estan registrados
    //creando mi propia API
    const respuesta = await fetch(url,{
        method:'GET',
    })
    const usuarios = await respuesta.json()
    // validacion si el usuario existe, voy el usuario que estoy colocando en el campo de recursos users

    const usuarioExiste = usuarios.find(i=>i.nombre === createInput.value)
    if(!createInput.value){
        // console.log('campos vacios')
        noti.textContent = ('El campo no puede estar vacio')
        //anadiendo clases
        noti.classList.add('show-notification')
        setTimeout(() => {
            noti.classList.remove('show-notification')
        },2500);
    }else if(usuarioExiste){
        // console.log('el usuario esta registrado')
        noti.textContent = ('El usuario esta registrado')
        noti.classList.add('show-notification')
        setTimeout(() => {
            noti.classList.remove('show-notification')
        },2500);
    }else{
        //el usuario existe
        //vamos a colocar datos dentro del recurso
        await fetch(url,{
            //vamos a colocar valores
            method:'POST',
            headers:{
                // indicando que es un json
                'Content-Type':'application/json'
                    },
            body:JSON.stringify({
                nombre:createInput.value
            })
            
        })
        noti.innerHTML = `El suario ${createInput.value} ha sido creado ` 
        noti.classList.add('show-notification')
        setTimeout(() => {
            noti.classList.remove('show-notification')
        },2500);
       
    }


    createInput.value = '';


})



formL.addEventListener('submit',async e=>{
    e.preventDefault();
    const url = 'http://localhost:3000/usuarios'
    //consulta
    const response = await fetch(url,{method:'GET'})
    const usuarios = await response.json();
    // si el usuario existe
    const usuarioExiste = usuarios.find(i=>i.nombre === loginInput.value)
    //console.log(usuarioExiste)
    if(!usuarioExiste){
        //caso de que no existe
        noti.textContent = ('el usuario no existe')
        noti.classList.add('show-notification');
        setTimeout(() => {
            noti.classList.remove('show-notification')
        },2500);
    }else{
        //caso si el usuario existe
       // console.log('el usuario existe')
       
       window.location.href = '../tareas/tareas.html'
       localStorage.setItem('usuarios',JSON.stringify(usuarios));
    }

})
