//Crear selectores
const usuarios = JSON.parse(localStorage.getItem('usuarios'));
const formulario = document.querySelector('#form-todos')
const lista = document.querySelector('#todos-list');
const inputF = document.querySelector('#form-input');
const cerrarbtn = document.querySelector('#cerrar-btn');
//console.log(usuarios)
if(!usuarios){
    window.location.href='/'
}

formulario.addEventListener('submit',async e=>{
    e.preventDefault();
    await fetch('http://localhost:3000/tareas',{
    method: 'POST',
    headers:{
        'Content-Type':'application/json'
    },
    body: JSON.stringify({text:inputF.value,nombre:usuarios.nombre})
    })
    //mostrar la lista de elelemtes en el html

    const listado = document.createElement('li');
    listado.innerHTML = `
    <li id=${lista.id} class="todo-item">
    <button class="delete-btn">&#10006;</button>
    ${inputF.value}
    <button class="check-btn">&#10003;</button>
  </li>

  `
  lista.appendChild(listado)
  inputF.value = '';
})

const obtenerLista = async () =>{
    const respuesta = await fetch('http://localhost:3000/tareas',{method:'GET'});
    const list = await respuesta.json();
    const usersList = list.filter(lista => lista.nombre === usuarios.nombre);

    usersList.forEach(i => {
        const listado = document.createElement('li');
        listado.innerHTML = `
        <li id=${i.id} class = "todo-item">
        <button class="delete-btn">&#10006;</button>
        <p ${i.checked ? 'class = "check-todo"':null}>${i.text}</p>

        <button class = "check-btn">&#10003;</button>
        </li>
        `;
        lista.appendChild(listado);
        
    });
}

obtenerLista();

lista.addEventListener('click', async e =>{
    if(e.target.classList.contains('delete-btn')){
        const id = e.target.parentElement.id

        await fetch (`http://localhost:3000/tareas/${id}`,{method:'DELETE'});
        e.target.parentElement.remove();
    }else if(e.target.classList.contains('check-btn')){
        const id = e.target.parentElement.id;
        
        const respuestaJSON = await fetch(`http://localhost:3000/tareas/${id}`,{
            method:'PATCH',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify({checked:e.target.parentElement.classList.contains('check-todo')? false:true})
        });
        const respuesta = await respuestaJSON.json();

        e.target.parentElement.classList.toggle('check-todo');
    }
})

cerrarbtn.addEventListener('click', async e=>{
    localStorage.removeItem('usuarios');
    window.location.href = '/4';
})